capt program drop dotdist
program define dotdist, rclass

version 11.0

* This program computes the minimal distance between the point P3 and the
* segment between P1 and P2. It returns the distance in dist and the
* closest point on the segment to P3.

syntax anything 
tokenize `anything'

mata P1 = st_matrix("`1'")
mata P2 = st_matrix("`2'")
mata P3 = st_matrix("`3'")

mata equal = P1 == P2
mata st_numscalar("equal",equal)

* The segment is a point *
if equal == 1 {
    mata P = P1
}
* The segment is not a point *
else {
	mata P = J(1,2,0)
    mata U = ((P3[1,1]-P1[1,1])*(P2[1,1]-P1[1,1]))+((P3[1,2]-P1[1,2])*(P2[1,2]-P1[1,2]))
    mata U = U/((P1[1,1]-P2[1,1])^2+(P1[1,2]-P2[1,2])^2)
	mata st_numscalar("U",U)
	* The closest point is in the segment *
    if U > 0 & U < 1 {
		mata P[1,1] = P1[1,1] + U*(P2[1,1]-P1[1,1])
        mata P[1,2] = P1[1,2] + U*(P2[1,2]-P1[1,2])
	}
    else if U < 0 {
        mata P[1,1] = P1[1,1]
        mata P[1,2] = P1[1,2]
    }
	else {
        mata P[1,1] = P2[1,1]
        mata P[1,2] = P2[1,2]
    }
}

* Calculate Distance *
mata dist = sqrt((P[1,1]-P3[1,1])^2+(P[1,2]-P3[1,2])^2)
mata mata drop P1 P2 P3 P
mata st_numscalar("dist",dist)
return scalar dist = dist

end
