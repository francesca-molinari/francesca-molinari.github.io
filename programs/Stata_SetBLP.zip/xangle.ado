capt program drop xangle
program define xangle, rclass

version 11.0

* This computes the angle of the line between (x1,y1) and (x2,y2)
* and positive of the X axis.  Varlist takes the form x1,y1,x2,y2.

syntax anything
tokenize "`anything'"

local px = `3' - `1'
local py = `4' - `2'
if `py' < 0 {
	local py = -1*`py'
	local flag = 1
}
else {
	local flag = 0
}

local xang = atan2(`py',abs(`px'))
if `px' < 0 {
	local xang = _pi - `xang'
}
if `flag' == 1 {
	local xang = (2*_pi) - `xang'
}

return scalar x = `xang'

end
