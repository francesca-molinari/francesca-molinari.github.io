capt program drop EY
program define EY, eclass

version 11.0

* This ado file calculates the identification region and the Hausdorff and directed
* Hausdorff distance that corresponds to the 95% confidence region of the inputted 
* data. The user can choose the number of bootstrap iterations with the 
* "reps" option, and the size of the bootstrap sample with the "size" 
* option. The default number of iterations is 50 and the default sample size
* is the size of the original data.  The nonparametric bootstrap is described 
* in Beresteanu and Molinari (2008) on page 780.

syntax varlist (min=2 max=2 default=none) [, REPS(integer 50) size(integer 0) LEVel(real .95) noCC noDU TESTnull(namelist min=1 max=1)]
tokenize `varlist'

qui{

count if `1' != . 
local nobs = r(N)

if `size' == 0{
	local size = `nobs'
}
if `size' != 0 {
	local size = `size'
}

capt assert `level' > 0 & `level' < 1
if _rc != 0 {
	di as error "Level must be specified between 0 and 1"
	exit
}
local alpha = `level'
local topboot = floor((1-`alpha')*`reps')

** True Identification Region **
egen lb = total(`1')
replace lb = lb/`nobs'
egen ub = total(`2')
replace ub = ub/`nobs'
local lb = lb[1]
local ub = ub[1]
drop lb ub

** Confidence Set **
mata r_H = J(`topboot',1,0)
mata r_dH = J(`topboot',1,0)
forvalues i = 1/`reps' {
	preserve
	bsample `size'
	
	egen lb_bs = total(`1')
	replace lb_bs = lb_bs/`size'
	egen ub_bs = total(`2')
	replace ub_bs = ub_bs/`size'
	local lb_bs = lb_bs[1]
	local ub_bs = ub_bs[1]
	drop ub* lb*
	
	** Hausdorff Distance **
    gen distboot_H = max(abs(`lb'-`lb_bs'), abs(`ub'-`ub_bs'))
	replace distboot_H = distboot_H * sqrt(`nobs')
	mata distboot_H = st_data(1,"distboot_H")
	** Find Least Distance - Hausdorff **
	mata minval_H = colmin(r_H)
	mata st_numscalar("minval_H",minval_H)
	mata r_H = sort(r_H,-1)
	if minval_H < distboot_H {
		mata r_H[`topboot'] = distboot_H
	}
	
	** Directed Hausdorff Distance **
	gen distboot_dH = max((`lb'-`lb_bs'),(`ub_bs'-`ub'))
	replace distboot_dH = max(distboot_dH,0)
	replace distboot_dH = distboot_dH * sqrt(`nobs')
	mata distboot_dH = st_data(1,"distboot_dH")	
	** Find Least Distance - Directed Hausdorff **
	mata minval_dH = colmin(r_dH)
	mata st_numscalar("minval_dH",minval_dH)
	mata r_dH = sort(r_dH,-1)
	if minval_dH < distboot_dH {
		mata r_dH[`topboot'] = distboot_dH
	}
	restore
}

mata minval_H = colmin(r_H)
mata st_numscalar("minval_H",minval_H)
mata minval_dH = colmin(r_dH)
mata st_numscalar("minval_dH",minval_dH)

ereturn scalar cr_H = minval_H 
ereturn scalar cr_dH = minval_dH
ereturn scalar lb = `lb'
ereturn scalar ub = `ub'
}

disp ""
disp "Estimated Identification Region for Mean = [lb , ub] = [" e(lb) " , " e(ub) "]"
disp ""
disp "Critical Value based on Hausdorff = cr_H = " e(cr_H)
disp "Critical Value based on directed Hausdorff = cr_dH = " e(cr_dH)

** Display Test Results **
noi disp ""
if "`testnull'" != "" {
	** Confirm test set if correctly specified **
	confirm matrix `testnull'
	if _rc != 0 {
		di as error "Null set to be tested is not defined as a matrix"
		exit
	}
	matrix ZZZZZ = `testnull'

	capture assert colsof(ZZZZZ) == 2
	if _rc != 0 {
		di as error "Null set has incorrect dimensions, please provide a 1x2 matrix"
		exit
	}	
	capture assert rowsof(ZZZZZ) == 1
	if _rc != 0 {
		di as error "Null set has incorrect dimensions, please provide a 1x2 matrix"
		exit
	}

	local lb_test = ZZZZZ[1,1]
	local ub_test = ZZZZZ[1,2]
	matrix drop ZZZZZ
	
	capture assert `lb_test' <= `ub_test'
	if _rc != 0 {
		di as error "Element 1 of null set should be lower value and element 2 should be upper value"
		exit
	}
	
	local H_true = max(abs(`lb'-`lb_test'), abs(`ub'-`ub_test')) 
	local H_true = `H_true' * sqrt(`nobs')
	qui gen dH_true = max((`lb'-`lb_test'),(`ub_test'-`ub'))
	qui replace dH_true = max(dH_true,0)
	qui replace dH_true = dH_true * sqrt(`nobs')
	local dH_true = dH_true[1]
	drop dH_true
	
	if `H_true' > e(cr_H) {
		noi disp "Hausdorff Distance = " `H_true' " therefore reject the null"
	}
	if `H_true' <= e(cr_H) {
		noi disp "Hausdorff Distance = " `H_true' " therefore fail to reject the null"
	}
	if `dH_true' > e(cr_dH) {
		noi disp "Directed Hausdorff Distance = " `dH_true' " therefore reject the null"
	}
	if `dH_true' <= e(cr_dH) {
		noi disp "Directed Hausdorff Distance = " `dH_true' " therefore fail to reject the null"
	}
}

** CC and DU **
if "`cc'" != "nocc" {
	ereturn scalar CC_L_1 = e(lb) - (e(cr_H)/sqrt(`nobs')) 
	ereturn scalar CC_L_2 = e(lb) + (e(cr_H)/sqrt(`nobs'))
	ereturn scalar CC_U_1 = e(ub) - (e(cr_H)/sqrt(`nobs')) 
	ereturn scalar CC_U_2 = e(ub) + (e(cr_H)/sqrt(`nobs'))
	disp ""
	disp "Confidence Collection based on Hausdorff, Lower = [CC_L_1 , CC_L_2] = [" e(CC_L_1) " , " e(CC_L_2) "]"
	disp "Confidence Collection based on Hausdorff, Upper = [CC_U_1 , CC_U_2] = [" e(CC_U_1) " , " e(CC_U_2) "]"
}
if "`du'" != "nodu" {
	ereturn scalar DU_L = e(lb) - (e(cr_dH)/sqrt(`nobs'))
	ereturn scalar DU_U = e(ub) + (e(cr_dH)/sqrt(`nobs'))
	disp ""
	disp "Confidence Set based on directed Hausdorff = [DU_L , DU_U] = [" e(DU_L) " , " e(DU_U) "]"
}

end
