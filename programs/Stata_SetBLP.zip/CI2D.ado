capt program drop CI2D
program define CI2D, eclass

version 11.0

** This program uses the nonparametric bootstrap described in Beresteanu and
** Molinari (2008) Algorithm 4.2.  The bracketing is done the way Chernozukov, 
** Hong and Tamer describe in their paper: section 4.5 of CHT (2004). 

syntax varlist (min=2 default=none) [, noINTercept REPS(integer 50) LEVel(real .95) TESTnull(namelist min=1 max=1)]
tokenize `varlist'
qui {

** Find Projection **
twoDproj `varlist', `intercept' nograph
matrix define Thetahat2 = e(Thetahat)

count if `1' != . 
local nobs = r(N)

** Find Hausdorff and Directed Hausdorff between Null Set and Projection **
if "`testnull'" != "" {
	HausdorffDist `testnull' Thetahat2
	local H_true = sqrt(`nobs')*r(hausdorff)
	local dH_true = sqrt(`nobs')*r(dhausdorff)
}
	
** Bootstrapping **
matrix H = J(`reps',1,0)
matrix dH = J(`reps',1,0)
forvalues i = 1/`reps' {
	if `i' == 1 {
		timer clear 1
		timer on 1
		preserve
		bsample `nobs'
	
		twoDproj `varlist', `intercept' nograph
		matrix define Thetastar = e(Thetahat)
	
		HausdorffDist Thetahat2 Thetastar
		matrix H[`i',1] = sqrt(`nobs')*r(hausdorff)
		matrix dH[`i',1] = sqrt(`nobs')*r(dhausdorff)
		restore
		timer off 1
		timer list
		noi disp ""
		noi disp "Estimated time for completion is " round((r(t1)*`reps')/60,.01) " minutes"
	}
	else {
		preserve
		bsample `nobs'
	
		twoDproj `varlist', `intercept' nograph
		matrix define Thetastar = e(Thetahat)
	
		HausdorffDist Thetahat2 Thetastar
		matrix H[`i',1] = sqrt(`nobs')*r(hausdorff)
		matrix dH[`i',1] = sqrt(`nobs')*r(dhausdorff)
		restore
	}
}

** Estimate Critical Value **
mata H = sort(st_matrix("H"),1)
mata dH = sort(st_matrix("dH"),1)
capt assert `level' > 0 & `level' < 1
if _rc != 0 {
	di as error "Level must be specified between 0 and 1"
	exit
}
local pos = floor(`level'*`reps')
mata cr_H = H[`pos',1]
mata cr_dH = dH[`pos',1]
mata st_numscalar("cr_H",cr_H)
mata st_numscalar("cr_dH",cr_dH)

ereturn scalar cr_H = cr_H
ereturn scalar cr_dH = cr_dH

noi disp ""
noi disp "Critical Value based on Hausdorff = cr_H = " e(cr_H)
noi disp "Critical Value based on directed Hausdorff = cr_dH = " e(cr_dH)

** Display Test Results **
noi disp ""
if "`testnull'" != "" {
	if `H_true' > e(cr_H) {
		noi disp "Hausdorff Distance = " `H_true' " therefore reject the null"
	}
	if `H_true' <= e(cr_H) {
		noi disp "Hausdorff Distance = " `H_true' " therefore fail to reject the null"
	}
	if `dH_true' > e(cr_dH) {
		noi disp "Directed Hausdorff Distance = " `dH_true' " therefore reject the null"
	}
	if `dH_true' <= e(cr_dH) {
		noi disp "Directed Hausdorff Distance = " `dH_true' " therefore fail to reject the null"
	}
}

** Find Confidence Regions **
* Organize Points of Thetahat Counterclockwise *
mata Thetahat2 = st_matrix("Thetahat2")
mata num = rows(Thetahat2)
mata avg = colsum(Thetahat2):/num
mata three = atan2((Thetahat2[.,2]:-avg[1,2]),(Thetahat2[.,1]:-avg[1,1]))
mata Thetahat2 = Thetahat2[.,1] , Thetahat2[.,2] , three
mata Thetahat2 = sort(Thetahat2,-3)
mata i = 0
mata w = 0
mata minindex(Thetahat2[.,2],1,i,w)
mata one = Thetahat2[(i::num),(1,2)]
mata two = Thetahat2[(1::(i-1)),(1,2)]
mata Thetahat2 = one \ two
matrix drop Thetahat2
mata st_matrix("Thetahat2",Thetahat2)
mata mata drop one two three Thetahat2 w i num avg

* Create Balls of Radius rH or rdH to Add (Minkowski) to Thetahat *
local rH = e(cr_H)/sqrt(`nobs')
local rdH = e(cr_dH)/sqrt(`nobs')

ball, radius(`rH') number(90)
matrix ball = r(B)
minksum Thetahat2 ball
matrix define ThetaCI_H = r(M)
ereturn matrix ThetaCI_H = ThetaCI_H, copy
matrix define finish = ThetaCI_H[1,1...]
matrix define ThetaCI_H = ThetaCI_H \ finish
matrix drop finish

ball, radius(`rdH') number(90)
matrix ball = r(B)
minksum Thetahat2 ball
matrix define ThetaCI_dH = r(M)
ereturn matrix ThetaCI_dH = ThetaCI_dH, copy
matrix define finish = ThetaCI_dH[1,1...]
matrix define ThetaCI_dH = ThetaCI_dH \ finish
matrix drop finish

** Plot Results **
matrix define finish = Thetahat2[1,1...]
matrix define Thetahat2 = Thetahat2 \ finish
matrix drop finish

gen orig = 1
svmat Thetahat2
svmat ThetaCI_H
svmat ThetaCI_dH
if "`testnull'" != "" {
	confirm matrix `testnull'
	if _rc != 0 {
		di as error "Null set to be tested is not defined as a matrix"
		exit
	}
	capture assert colsof(`testnull') == 2
	if _rc != 0 {
		di as error "Null set has incorrect dimensions, please provide a matrix with 2 columns"
		exit
	}
	svmat `testnull'
	if e(cr_H) == e(cr_dH) {
		twoway line ThetaCI_H2 ThetaCI_H1, lpattern(dash) color(blue) xtitle(Theta1) ytitle(Theta2) title(2D Projection and Confidence Regions) note(Note: Hausdorff and directed Hausdorff confidence regions are equivalent.) legend(cols(2) label(1 "Hausdorff") label(2 "Directed Hausdorff") label(4 "Projection") label(3 "Null Set") order(4 3 - "Confidence Regions:" - 1 2)) || line ThetaCI_dH2 ThetaCI_dH1, lpattern(dash) color(green) || line `testnull'2 `testnull'1, color(red) || line Thetahat22 Thetahat21, color(black) 
	}
	if e(cr_H) != e(cr_dH) {
		twoway line ThetaCI_H2 ThetaCI_H1, lpattern(dash) color(blue) xtitle(Theta1) ytitle(Theta2) title(2D Projection and Confidence Regions) legend(cols(2) label(1 "Hausdorff") label(2 "Directed Hausdorff") label(4 "Projection") label(3 "Null Set") order(4 3 - "Confidence Regions:" - 1 2)) || line ThetaCI_dH2 ThetaCI_dH1, lpattern(dash) color(green) || line `testnull'2 `testnull'1, color(red) || line Thetahat22 Thetahat21, color(black) 
	}
	drop `testnull'1 `testnull'2
}
if "`testnull'" == "" {
	if e(cr_H) == e(cr_dH) {
		twoway line ThetaCI_H2 ThetaCI_H1, lpattern(dash) color(blue) xtitle(Theta1) ytitle(Theta2) title(2D Projection and Confidence Regions) note(Note: Hausdorff and directed Hausdorff confidence regions are equivalent.) legend(cols(2) holes(2) label(1 "Hausdorff") label(2 "Directed Hausdorff") label(3 "Projection") order(3 - "Confidence Regions:" - 1 2)) || line ThetaCI_dH2 ThetaCI_dH1, lpattern(dash) color(green) || line Thetahat22 Thetahat21, color(black)
	}
	if e(cr_H) != e(cr_dH) {
		twoway line ThetaCI_H2 ThetaCI_H1, lpattern(dash) color(blue) xtitle(Theta1) ytitle(Theta2) title(2D Projection and Confidence Regions) legend(cols(2) holes(2) label(1 "Hausdorff") label(2 "Directed Hausdorff") label(3 "Projection") order(3 - "Confidence Regions:" - 1 2)) || line ThetaCI_dH2 ThetaCI_dH1, lpattern(dash) color(green) || line Thetahat22 Thetahat21, color(black)
	}
}
drop if orig == .
drop Theta* orig

ereturn matrix Thetahat = Thetahat2

matrix drop Thetastar ThetaCI_dH ThetaCI_H dH H ball

}

end
