capt program drop BLPcalculator
program define BLPcalculator, eclass

version 11.0

syntax varlist (min=4 max=4 default=none)
tokenize `varlist'

qui count
local n = r(N)

** Calculating Sigma hat of Formula 4.5 in Beresteanu & Molinari (2008) **
tempvar sum_r1_2 sum_r2_2 sum_r1_r2
egen `sum_r1_2' = total(`3'*`3')
egen `sum_r2_2' = total(`4'*`4')
egen `sum_r1_r2' = total(`3'*`4')
matrix define Sigma_hat = [`sum_r1_2'[1], `sum_r1_r2'[1] \ `sum_r1_r2'[1], `sum_r2_2'[1]]

* Deal with Missing Values **
capt assert `3'[1] ! = . & `4'[1] ! = . & `1'[1] ! = . & `2'[1] ! = .
if _rc != 0 {
	sort `3'
}

capt assert `3'[1] ! = . & `4'[1] ! = . & `1'[1] ! = . & `2'[1] ! = .
if _rc != 0 {
	noi di as error "All missing values in data"
}

** Calculating G-bar of Formula 4.5 in Beresteanu & Molinari (2008) **
* Compute the initial set - guarantees correct ordering of points *
if (`4'[1]*`1'[1]) < (`4'[1]*`2'[1]) {
	matrix define Mold = [`3'[1]*`1'[1],  `4'[1]*`1'[1] \ `3'[1]*`2'[1], `4'[1]*`2'[1]]
}
if (`4'[1]*`1'[1]) > (`4'[1]*`2'[1]) {
	matrix define Mold = [`3'[1]*`2'[1], `4'[1]*`2'[1] \ `3'[1]*`1'[1],`4'[1]*`1'[1]]
}
if (`4'[1]*`1'[1]) == (`4'[1]*`2'[1]) {
	if (`3'[1]*`1'[1]) < (`3'[1]*`2'[1]) {
		matrix define Mold = [`3'[1]*`1'[1],  `4'[1]*`1'[1] \ `3'[1]*`2'[1], `4'[1]*`2'[1]]
	}
	else {
		matrix define Mold = [`3'[1]*`2'[1],  `4'[1]*`2'[1] \ `3'[1]*`1'[1], `4'[1]*`1'[1]]
	}
}
if ((`4'[1]*`1'[1]) == (`4'[1]*`2'[1])) & ((`3'[1]*`1'[1]) == (`3'[1]*`2'[1])) {
	* noi di as error "Non-unique points in Minkowski Summation"
}

* Compute all other sets - guarantees correct ordering of points *
forvalues j = 2/`n' {
	if `3'[`j'] != . & `4'[`j'] != . & `1'[`j'] != . & `2'[`j'] != . {
		if (`4'[`j']*`1'[`j']) < (`4'[`j']*`2'[`j']) {
			matrix define P2 = [`3'[`j']*`1'[`j'], `4'[`j']*`1'[`j'] \ `3'[`j']*`2'[`j'], `4'[`j']*`2'[`j']]
		}
		if  (`4'[`j']*`1'[`j']) > (`4'[`j']*`2'[`j']) {
			matrix define P2 = [`3'[`j']*`2'[`j'], `4'[`j']*`2'[`j'] \ `3'[`j']*`1'[`j'], `4'[`j']*`1'[`j']]
		}
		if (`4'[`j']*`1'[`j']) == (`4'[`j']*`2'[`j']) {
			if (`3'[`j']*`1'[`j']) < (`3'[`j']*`2'[`j']) {
				matrix define P2 = [`3'[`j']*`1'[`j'],  `4'[`j']*`1'[`j'] \ `3'[`j']*`2'[`j'], `4'[`j']*`2'[`j']]
			}
			else {
				matrix define P2 = [`3'[`j']*`2'[`j'],  `4'[`j']*`2'[`j'] \ `3'[`j']*`1'[`j'], `4'[`j']*`1'[`j']]
			}
		}
		if ((`4'[`j']*`1'[`j']) == (`4'[`j']*`2'[`j'])) & ((`3'[`j']*`1'[`j']) == (`3'[`j']*`2'[`j'])) {
			* noi di as error "Non-unique points in Minkowski Summation"
		}

		* Calculating the sum over all observations via Minkowski Sum *      
		minksum Mold P2
		matrix define M2 = r(M)
		matrix drop Mold
		matrix define Mold = M2
		matrix drop P2	
	}
}

** Calculating Estimator **
matrix Theta_hat = M2*invsym(Sigma_hat)

** Save Results **
ereturn clear
ereturn matrix Thetahat = Theta_hat

matrix drop M2 Sigma_hat Mold

end
