capt program drop ball
program define ball, rclass

version 11.0

** This program creates a 2-ball with radius specified in the "radius" option and 
** number of angle divisions is specified in "number" option.  The default radius 
** is 1 and default number of angle divisions is 360.  Ball is assumed centered
** at the origin and coordinates are ordered with smallest y-value first and 
** continues counter-clockwise.

syntax [, RADius(real 1) NUMber(integer 360)]

local increment = 360/`number'
local radian = 270 * (_pi/180)
forvalues i = 1/`number' {
	local x = `radius'*cos(`radian')
	local y = `radius'*sin(`radian')
	if `i' == 1 {
		matrix define B = [`x',`y']
	}
	else {
		matrix define newB = [`x',`y']
		matrix define B = B \ newB
	}
	local radian = (270+(`increment'*`i')) * (_pi/180)
}

return matrix B = B

matrix drop newB

end
