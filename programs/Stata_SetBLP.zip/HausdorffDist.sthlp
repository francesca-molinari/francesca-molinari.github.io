{smcl}
{* *! version 1.0.0  3feb2010}{...}
{cmd:help HausdorffDist}{right:dialog:  {dialog HausdorffDist}{space 1}}
{right:also see:  {help CI2D}}
{hline}

{title:Title}

{p2colset 5 22 24 2}{...}
{p2col : HausdorffDist {hline 2}} Computes the Hausdorff and directed Hausdorff distance between two convex sets to be used to implement inference 
	of the two-dimensional identification regions of BLP coefficients in {help CI2D}{p_end}
{p2colreset}{...}


{title:Syntax}

{p 8 18 2}
{cmd:HausdorffDist} P Q

{title:Description}

{pstd}
{cmd:HausdorffDist} computes the Hausdorff and directed Hasudorff distance between two convex polygons P and Q.  The polygons are represented by their vertices and must be ordered with the 
	smallest y-value first (x-value in case of a tie) and continued counter-clockwise.  This ordering is maintained when using {help twoDproj} and {help CI2D}
	by the conditions in {help BLPcalculator}.  P and Q must be specified as Stata matrices.
	
{pstd}
This command is called by {help CI2D} which implements estimation and inference of the two-dimensional identification regions of BLP coefficients 
from Beresteanu and Molinari (Econometrica, 2008).

{title:Examples}

{pstd}Hausdorff and directed Hausdorff distance between two balls in R^2 requested{p_end}
{phang2}{cmd:. ball, radius(2) number(60)}{p_end}
{phang2}{cmd:. matrix A = r(B)}{p_end}
{phang2}{cmd:. ball, radius(1) number(60)}{p_end}
{phang2}{cmd:. matrix B = r(B)}{p_end}
{phang2}{cmd:. HausdorffDist A B}{p_end}

{title:Saved results}

{pstd}
{cmd:HausdorffDist} saves the following in {cmd:r()}:

{synoptset 25 tabbed}{...}
{p2col 5 25 29 2: Scalars}{p_end}
{synopt:{cmd:r(hausdorff)}}Hausdorff distance{p_end}
{synopt:{cmd:r(dhausdorff)}}Directed Hausdorff distance{p_end}

{p2colreset}{...}

{title:Also see}

{psee}
{space 2}Help: {help CI2D}{break}
{p_end}
