{smcl}
{* *! version 1.0.0  3feb2010}{...}
{cmd:help CI2D}{right:dialog:  {dialog CI2D}{space 1}}
{right:also see:  {help twoDproj}}
{hline}

{title:Title}

{p2colset 5 22 24 2}{...}
{p2col : CI2D {hline 2}} Implements estimation and inference of the two-dimensional identification regions of BLP coefficients from Beresteanu and 
Molinari (Econometrica, 2008) using the method described in Algorithm 4.2{p_end}
{p2colreset}{...}

{title:Syntax}

{p 8 18 2}
{cmd:CI2D}
	Ylow Yhigh XProj1 [XProj2] XOther1 XOther2 ...
	[{cmd:,} {it:options} {cmd:nointercept reps(#) level(#) testnull(M)}]

{synoptset 24 tabbed}{...}
{synopthdr}
{synoptline}

{synopt :{opt noint:ercept}} Estimate the two-dimensional identification region of XProj1 with XProj2; 
	default is to estimate the two-dimensional identification region of the intercept with XProj1.{p_end}
{synopt :{opt reps:}} Perform # bootstrap replications; default is reps(50). {p_end}
{synopt :{opt lev:el}} Set confidence level; default is level(.95). {p_end}
{synopt :{opt test:null(M)}} Implements hypothesis tests of inclusion/equality of test set M of two-dimensional BLP coefficient region with the 
	estimated two-dimensional identification region for the specified BLP coefficients.  {p_end}

{title:Description}

{pstd}
{cmd:CI2D} implements estimation and inference of the two-dimensional identification regions for specified components of the BLP coefficient vector as 
described in Beresteanu and Molinari (Econometrica, 2008).  Typing

{phang2}
{cmd:. CI2D} Ylow Yhigh XProj1 XOther1 XOther2

{pstd}
executes the estimation procedure based on three X variables, displaying the estimated two-dimensional identification region
of the first X variable, specified as XProj1, and the intercept.  Note that the Ylow variable contains the lower 
bounds on the dependent variable and the Yhigh variable contains the upper bounds on the dependent variable.

{pstd}
This command also implements inference using nonparameteric bootstrap to obtain the following statistics:

{phang2}
(1) Critical values to use for inference regarding the two-dimensional identification region of the specified components of the BLP coefficient vector based 
	on the Hausdorff and directed Hausdorff distances.

{phang2}
(2) Graph of confidence regions for the estimated two-dimensional identification region of the specified components of the BLP coefficient vector based 
	on the Hausdorff and directed Hausdorff distances.

{phang2}
(3) Conclusion from hypothesis tests of the two-dimensional BLP coefficient set specified in the test option with the estimated two-dimensional identification 
	region for the specified BLP coefficents.

	{phang2}
(4) Graph of the two-dimensional BLP coefficient set specified in the test option if the test option is specified.
	
{pstd}
This command is an extension of {cmd:twoDproj}.  If you are only interested in estimation and not inference of the identification regions, then
use {cmd:twoDproj} since the bootstrap method in {cmd:CI2D} would require unnecessary computing time.

{title:Options}

{pstd}
{cmd:testnull} implements hypothesis tests for inclusion/equality of the test set, specified in matrix M, with the estimated two-dimensional identification 
region for the specified BLP coefficients via the critical values based on the directed Hausdorff/Hausdorff distances.  M must be specified as a Stata matrix and 
must be a k x 2 matrix of coordinates of the region to be tested (where k can be any number) that are ordered counter-clockwise starting with the smallest y-value 
(smallest x-value in case of a tie).
  The first column of M must contain the coordinate for the axis corresponding to the
first coefficient, while the second column of matrix M must contain the coordinate for the axis corresponding to the second coefficient. 

{title:Examples}

{pstd}Three Xs, two-dimensional projection of first two Xs requested at 90% confidence level{p_end}
{phang2}{cmd:. CI2D Ylow Yhigh X1 X2 X3, nointercept lev(.90)}{p_end}

{pstd}One X, test of set of the intercept and first BLP coefficient with 100 replications{p_end}
{phang2}{cmd:. matrix M = [-1,-1\1,-1\1,1\-1,1]}{p_end}
{phang2}{cmd:. CI2D Ylow Yhigh X1, test(M) reps(100)}{p_end}

{title:Saved results}

{pstd}
{cmd:CI2D} saves the following in {cmd:e()}:

{synoptset 25 tabbed}
{p2col 5 25 29 2: Scalars}{p_end}
{synopt:{cmd:e(cr_H)}}Critical value based on Hausdorff distance{p_end}
{synopt:{cmd:e(cr_H)}}Critical value based on directed Hausdorff distance{p_end}

{synoptset 25 tabbed}{...}
{p2col 5 25 29 2: Matrices}{p_end}
{synopt:{cmd:e(Thetahat)}}Matrix of coordinates for the estimated two-dimensional identification region of specified BLP coefficients{p_end}
{synopt:{cmd:e(ThetaCI_H)}}Matrix of coordinates for the confidence region of specified BLP coefficients, based on Hausdorff distance{p_end}
{synopt:{cmd:e(ThetaCI_dH)}}Matrix of coordinates for the confidence region of specified BLP coefficients, based on directed Hausdorff distance{p_end}

{p2colreset}{...}

{title:Also see}

{psee}
{space 2}Help:  {help twoDproj}{break}
{p_end}
