capt program drop HausdorffDist
program define HausdorffDist, rclass

version 11.0

* This functions computes the Hausdorff distance between two convex polygons
* P and Q that may or may not overlap. The polygons P and Q are given in
* their V-representation. That means P is a a x 2 matrix and Q is a b x 2
* matrix each containing the verteces of P and Q respectively. The verteces
* are given in a counter clock-wise manner.

syntax anything 
tokenize `anything'

local a = rowsof("`1'")
local b = rowsof("`2'")
matrix A = `1'
matrix B = `2'
		
* Starting Point of A and B *
matrix A0 = A[1,1...]
matrix B0 = B[1,1...]
* Completing the circle of A and B *
matrix A = [A\ A0]
matrix B = [B\ B0]

** Computing the Directed Hausdorff Distance from A to B **
forvalues i = 1/`a' {
	local dstarAB = 0
    * Compute inf||a-b|| with respect to b *
    forvalues j = 1/`b' {
		matrix one = B[`j',1...]
		matrix two = B[(`j'+1),1...]
		matrix three = A[`i',1...]
        dotdist one two three
		local newdist = r(dist)		 
        if `j' == 1 {
            local dist = `newdist'
        }
        if (`dist' > `newdist') & (`j' != 1) {
            local dist = `newdist'
        }
    }
    if `i' == 1 {
        local dstarAB = `dist'
    }
    if (`dstarAB' < `dist') & (`i' != 1) {
        local dstarAB = `dist'
    }
}
    
** Computing the Directed Hausdorff Distance from B to A **
forvalues i = 1/`b' {
	local dstarBA = 0
    * Compute inf||b-a|| with respect to a *
    forvalues j = 1/`a' {
		matrix one = A[`j',1...]
		matrix two = A[(`j'+1),1...]
		matrix three = B[`i',1...]
        dotdist one two three
		local newdist = r(dist)		 
        if `j' == 1 {
            local dist = `newdist'
        }
        if (`dist' > `newdist') & (`j' != 1) {
            local dist = `newdist'
        }
    }
    if (`dstarBA' < `dist') {
        local dstarBA = `dist'
    }
}
local max = max(`dstarAB', `dstarBA')
return scalar hausdorff = `max'
return scalar dhausdorff = `dstarAB'

matrix drop one two three A B A0 B0

end
 