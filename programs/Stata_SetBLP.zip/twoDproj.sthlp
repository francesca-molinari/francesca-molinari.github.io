{smcl}
{* *! version 1.0.0  3feb2010}{...}
{cmd:help twoDproj}{right:dialog:  {dialog twoDproj}{space 1}}
{right:also see:  {help CI2D}}
{hline}

{title:Title}

{p2colset 5 22 24 2}{...}
{p2col : twoDproj {hline 2}} Implements estimation of the two-dimensional identification regions of BLP coefficients from Beresteanu and 
Molinari (Econometrica, 2008){p_end}
{p2colreset}{...}


{title:Syntax}

{p 8 18 2}
{cmd:twoDproj}
	Ylow Yhigh XProj1 [XProj2] XOther1 XOther2 ...
	[{cmd:,} {it:options} {cmd: nointercept nograph}]

{synoptset 24 tabbed}{...}
{synopthdr}
{synoptline}

{synopt :{opt noint:ercept}} Estimate the two-dimensional identification region of XProj1 with XProj2; 
	default is to estimate the two-dimensional identification region of the intercept with XProj1. {p_end}
{synopt :{opt nograph:}} Suppress the output of the graph of the estimated identification region; results
	can still be accessed via {manhelp ereturn R:ereturn}. {p_end}

{title:Description}

{pstd}
{cmd:twoDproj} implements estimation of the two-dimensional identification region for two specified components of BLP coefficient vector as described
	in Beresteanu and Molinari (Econometrica, 2008).  Typing

{phang2}
{cmd:. twoDproj} Ylow Yhigh XProj1 XOther1 XOther2

{pstd}
executes the estimation procedure based on three X variables, displaying the estimated two-dimensional identification region
of the first X variable, specified as XProj1, and the intercept.  Note that the Ylow variable contains the lower 
bounds on the dependent variable and the Yhigh variable contains the upper bounds on the dependent variable.

{pstd}
This command should be used with {cmd:CI2D} to calculate critical values and confidence collections/sets 
via nonparametric bootstrap.

{title:Examples}

{pstd}Five Xs, 2-dimensional projection of the intercept and X4 requested{p_end}
{phang2}{cmd:. twoDproj Ylow Yhigh X4 X1 X2 X3 X5}{p_end}

{pstd}Seven Xs, 2-dimensional projection of X2 and X5 requested{p_end}
{phang2}{cmd:. twoDproj Ylow Yhigh X2 X5 X1 X3 X4 X6 X7, nointercept}{p_end}

{title:Saved results}

{pstd}
{cmd:twoDproj} saves the following in {cmd:e()}:

{synoptset 25 tabbed}{...}
{p2col 5 25 29 2: Matrices}{p_end}
{synopt:{cmd:e(Thetahat)}}Matrix of coordinates for the estimated 2-dimensional identification region of specified BLP coefficients{p_end}

{p2colreset}{...}


{title:Also see}

{psee}
{space 2}Help:  {help CI2D}{break}
{p_end}
