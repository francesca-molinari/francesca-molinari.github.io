capt program drop minksum
program define minksum, rclass

version 11.0

* Computes the minkowski sum of two convex polygons: P and Q. The polygons
* are represented by their vertices and are ordered counter clockwise such
* that the first vertex will be the one who has the smallest Y coordinate
* (and smallest X coordinate in case of a tie).  This assumption is maintained
* in twoDproj.ado by conditions in BLPcalculator.ado.

syntax anything 
tokenize `anything'

local m = rowsof("`1'")
local n = rowsof("`2'")

* It is important that the P polygon will end with the largest angle and 
* not the Q polygon. That means that we need to look at the last vertex of P and
* the last vertex of Q and compare the angle that each creates with the 
* first vertex of the corresponding polygon. These angles are denoted as
* angP and angQ. If angP < angQ then we need to switch the order.

local tol=1e-10
xangle `1'[`m',1] `1'[`m',2] `1'[1,1] `1'[1,2]
local angP = r(x)
xangle `2'[`n',1] `2'[`n',2] `2'[1,1] `2'[1,2]
local angQ = r(x)

matrix define M = J(1,2,.)

local i = 1
local j = 1
if `angP' > `angQ' {
    while (`i' < `m'+1) | (`j' < `n'+1) {
        local current_i = min(mod(`i',`m'+1)+1,`i')
        local current_j = min(mod(`j',`n'+1)+1,`j')
        local next_i = min(mod(`i'+1,`m'+1)+1,`i'+1)
        local next_j = min(mod(`j'+1,`n'+1)+1,`j'+1)

		matrix M = M \ [`1'[`current_i',1...]+`2'[`current_j',1...]]
	
		xangle `1'[`current_i',1] `1'[`current_i',2] `1'[`next_i',1] `1'[`next_i',2]
		local angP = r(x)
		xangle `2'[`current_j',1] `2'[`current_j',2] `2'[`next_j',1] `2'[`next_j',2]
		local angQ = r(x)
		
        local iinc = 0
        local jinc = 0
        if (`angP' <= (`angQ'+`tol')) | (`j'==`n'+1) {
            local iinc = 1
        }
        if (`angP' >= (`angQ'-`tol')) | (`i'==`m'+1) {
            local jinc = 1
        }
        local i = `i' + `iinc'
        local j = `j' + `jinc'
        local i = min(`i',`m'+1)
        local j = min(`j',`n'+1)
	}
}
else {
    while (`i' < `m'+1) | (`j' < `n'+1) {
        local current_i = min(mod(`i',`m'+1)+1,`i')
        local current_j = min(mod(`j',`n'+1)+1,`j')
        local next_i = min(mod(`i'+1,`m'+1)+1,`i'+1)
        local next_j = min(mod(`j'+1,`n'+1)+1,`j'+1)

		matrix M = M \ [`1'[`current_i',1...]+`2'[`current_j',1...]]
	
		xangle `1'[`current_i',1] `1'[`current_i',2] `1'[`next_i',1] `1'[`next_i',2]
		local angP = r(x)
		xangle `2'[`current_j',1] `2'[`current_j',2] `2'[`next_j',1] `2'[`next_j',2]
		local angQ = r(x)
		
        local iinc = 0
        local jinc = 0
        if (`angQ' <= `angP') | (`i'==`m'+1) {
            local jinc = 1
        }
        if (`angQ' >= `angP') | (`j'==`n'+1) {
            local iinc = 1
        }
        local i = `i' + `iinc'
        local j = `j' + `jinc'
        local i = min(`i',`m'+1)
        local j = min(`j',`n'+1)
	}
}

matrix M = M[2...,1...]
return matrix M = M

end
