{smcl}
{* *! version 1.0.0  3feb2010}{...}
{cmd:help dotdist}{right:dialog:  {dialog dotdist}{space 1}}
{right:also see:  {help HausdorffDist} {help CI2D}}
{hline}

{title:Title}

{p2colset 5 22 24 2}{...}
{p2col : dotdist {hline 2}} Computes the minimal distance between a point and a line segment to be used to calculate the Hausdorff and directed Hausdorff distances
 in {help HausdorffDist}{p_end}
{p2colreset}{...}


{title:Syntax}

{p 8 18 2}
{cmd:dotdist} P Q R

{title:Description}

{pstd}
{cmd:dotdist} computes the minimal distance between the point, R, and the segment between P and Q.  P, Q and R must be specified as Stata
matrices of dimension 1 x 2.
	
{pstd}
This command is called by {help HausdorffDist} which calculates the Hausdorff and directed Hausdorff distances of two convex sets.   {help HausdorffDist} 
is called by {help CI2D} which implements estimation and inference of the two-dimensional identification regions of BLP coefficients 
from Beresteanu and Molinari (Econometrica, 2008).

{title:Examples}

{pstd}Distance between (1,2) and the segment between (3,4) and (5,6) {p_end}
{phang2}{cmd:. matrix A = [1,2]}{p_end}
{phang2}{cmd:. matrix B = [3,4]}{p_end}
{phang2}{cmd:. matrix C = [5,6]}{p_end}
{phang2}{cmd:. dotdist B C A}{p_end}

{title:Saved results}

{pstd}
{cmd:dotdist} saves the following in {cmd:r()}:

{synoptset 25 tabbed}{...}
{p2col 5 25 29 2: Scalers}{p_end}
{synopt:{cmd:r(dist)}}Minimal distance of interest{p_end}

{p2colreset}{...}

{title:Also see}

{psee}
{space 2}Help:  {help HausdorffDist} , {help CI2D}{break}
{p_end}
