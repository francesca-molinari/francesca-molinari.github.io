capt program drop twoDproj
program define twoDproj, eclass

version 11.0

* This ado file computes the 2-dimensional projection of the identification
* set on two dimensions of the explanatory variables. The intercept is included by default but can be excluded  
* with the 'nointercept' option.  This program displays the bounds in a graph and also saves
* the results that are accessible via ereturn.

syntax varlist (min=2 default=none) [, noINTercept noGRAPH]
tokenize `varlist'

qui {

* Checking Projection Dimension Specification *
local xnum : word count `varlist'
local xnum = `xnum' - 1
capt assert (`dim'+1) <= `xnum'
if _rc != 0 {
	noi di as error "dimension requested is larger than the dimension of X"
	exit
}
tempvar missing
gen `missing' = `1' == . | `2' == .

* Create Temporary Intercept Variable and YLow Yhigh Variables *
local 0 = "`1'"
local 1 = "`2'"
tempvar constant R1 R2 
gen `constant' = 1
local 2 = "`constant'"

* Calculating the Projection Interval *
local all = `xnum' + 1

capt assert "`4'" != "" if "`intercept'" == "nointercept"
if _rc != 0 {
	noi di as error "two projection variables must be specified if nointercept option is invoked"
	exit
}

if "`intercept'" == "nointercept" {
	local rest = "`2'"
	forvalues j = 5/`all' {
		* local rest = "`rest'" + " " + "``j''"
		local rest "`rest' ``j''"
	}
	forvalues i = 3/4 {
		local k = `i' - 2
		reg ``i'' `rest' if `missing' == 0 , noconstant
		predict `R`k'' if e(sample)==1, resid
	}	
}
if "`intercept'" != "nointercept" {
	local rest	
	forvalues j = 4/`all' {
		* local rest = "`rest'" + " " + "``j''"
		local rest "`rest' ``j''"
	}
	forvalues i = 2/3 {
		local k = `i' - 1
		reg ``i'' `rest' if `missing' == 0, noconstant
		predict `R`k'' if e(sample) == 1, resid
	}
}

BLPcalculator `0' `1' `R1' `R2'

if "`graph'" != "nograph" {
	matrix define Thetahat = e(Thetahat)
	matrix define finish = Thetahat[1,1...]
	matrix define Thetahat = Thetahat \ finish
	matrix drop finish
	gen orig = 1
	svmat Thetahat
	twoway line Thetahat2 Thetahat1
	drop if orig == .
	drop Thetahat1 Thetahat2 orig
	matrix drop Thetahat
}

}

end
