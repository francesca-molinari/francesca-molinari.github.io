{smcl}
{* *! version 1.0.0  3feb2010}{...}
{cmd:help BLPcalculator}{right:dialog:  {dialog BLPcalculator}{space 1}}
{right:also see:  {help twoDproj} {help minksum}}
{hline}

{title:Title}

{p2colset 5 22 24 2}{...}
{p2col : BLPcalculator {hline 2}} Computes the estimated two-dimensional identification regions of the BLP coefficients used with inputs derived in {help twoDproj}
	based on results from Beresteanu and Molinari (Econometrica, 2008){p_end}
{p2colreset}{...}

{title:Syntax}

{p 8 18 2}
{cmd:BLPcalculator} var1 var2 var3 var4

{title:Description}

{pstd}
{cmd:BLPcalculator} computes the estimated two-dimensional identification regions of the BLP coefficients
based on results from Beresteanu and Molinari (Econometrica, 2008). This command is called by {help twoDproj} which creates the 
correct inputs for {cmd:BLPcalculator} to implement estimation of the two-dimensional identification regions of BLP coefficients.  
This command also uses {help minksum}.

{title:Saved results}

{pstd}
{cmd:BLPcalculator} saves the following in {cmd:e()}:

{synoptset 25 tabbed}{...}
{p2col 5 25 29 2: Matrices}{p_end}
{synopt:{cmd:e(Thetahat)}}Matrix of coordinates for the estimated two-dimensional identification region of specified BLP coefficients{p_end}

{p2colreset}{...}

{title:Also see}

{psee}
{space 2}Help: {help twoDproj} , {help minksum}{break}
{p_end}
