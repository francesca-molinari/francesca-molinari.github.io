{smcl}
{* *! version 1.0.0  3feb2010}{...}
{cmd:help xangle}{right:dialog:  {dialog xangle}{space 1}}
{right:also see:  {help minksum} {help twoDproj}}
{hline}

{title:Title}

{p2colset 5 22 24 2}{...}
{p2col : xangle {hline 2}} Computes the angle of the line between two points and the x-axis to be used to estimate the two-dimensional identification region
 in {help twoDproj}{p_end}
{p2colreset}{...}


{title:Syntax}

{p 8 18 2}
{cmd:xangle} x1 y1 x2 y2

{title:Description}

{pstd}
{cmd:xangle} computes the angle formed by the line between two points, (x1,y1) and (x2,y2), and the positive x-axis.
	
{pstd}
This command is called by {help minksum} which calculates the Minkowski summation of two convex sets, which in turn is called by {help twoDproj} which 
implements estimation of the two-dimensional identification regions of BLP coefficients 
from Beresteanu and Molinari (Econometrica, 2008).

{title:Examples}

{pstd}Angle between (1,2) and (2,3) requested{p_end}
{phang2}{cmd:. xangle 1 2 3 4}{p_end}

{title:Saved results}

{pstd}
{cmd:xangle} saves the following in {cmd:r()}:

{synoptset 25 tabbed}{...}
{p2col 5 25 29 2: Scalers}{p_end}
{synopt:{cmd:r(x)}}Angle of interest{p_end}

{p2colreset}{...}

{title:Also see}

{psee}
{space 2}Help:  {help minksum} , {help twoDproj}{break}
{p_end}
