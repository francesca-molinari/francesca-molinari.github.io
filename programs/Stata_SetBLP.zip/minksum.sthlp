{smcl}
{* *! version 1.0.0  3feb2010}{...}
{cmd:help minksum}{right:dialog:  {dialog minksum}{space 1}}
{right:also see:  {help BLPcalculator} {help twoDproj} {help CI2D}}
{hline}

{title:Title}

{p2colset 5 22 24 2}{...}
{p2col : minksum {hline 2}} Computes the Minkowski sum of two convex sets to be used to compute the BLP in 
	{help BLPcalculator} and to create two-dimensional confidence regions in {help CI2D}{p_end}
{p2colreset}{...}


{title:Syntax}

{p 8 18 2}
{cmd:minksum} P Q

{title:Description}

{pstd}
{cmd:minksum} computes the Mimkowski sum of two convex polygons P and Q.  The polygons are represented by their vertices and must be ordered with the 
	smallest y-value first (smallest x-value in case of a tie) and continued counter-clockwise.  This ordering is maintained when using {help twoDproj} and {help CI2D}
	by the conditions in {help BLPcalculator}.  P and Q must be specified as Stata matrices.
	
{pstd}
This command is called by {help CI2D} which implements estimation and inference of the two-dimensional identification regions of BLP coefficients 
from Beresteanu and Molinari (Econometrica, 2008) and by {help twoDproj} (via {help BLPcalculator}) which implements estimation 
of the two-dimensional identification regions of BLP coefficients from Beresteanu and Molinari (Econometrica, 2008).

{title:Examples}

{pstd}Minkowski sum of two balls in R^2 requested{p_end}
{phang2}{cmd:. ball, radius(2) number(60)}{p_end}
{phang2}{cmd:. matrix A = r(B)}{p_end}
{phang2}{cmd:. ball, radius(1) number(60)}{p_end}
{phang2}{cmd:. matrix B = r(B)}{p_end}
{phang2}{cmd:. minksum A B}{p_end}

{title:Saved results}

{pstd}
{cmd:minksum} saves the following in {cmd:r()}:

{synoptset 25 tabbed}{...}
{p2col 5 25 29 2: Matrices}{p_end}
{synopt:{cmd:r(M)}}Matrix of coordinates for Minkowski sum of two convex sets{p_end}

{p2colreset}{...}

{title:Also see}

{psee}
{space 2}Help:  {help BLPcalculator} , {help twoDproj} , {help CI2D}{break}
{p_end}
