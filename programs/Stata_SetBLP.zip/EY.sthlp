{smcl}
{* *! version 1.0.0  3feb2010}{...}
{cmd:help EY}{right:dialog:  {dialog EY}{space 1}}
{right:also see:  {help oneDproj} {help CI1D}}
{hline}

{title:Title}

{p2colset 5 22 24 2}{...}
{p2col : EY {hline 2}} Implements estimation and inference of the identification set for the mean from Beresteanu and 
Molinari (Econometrica, 2008) using the method described on page 780{p_end}
{p2colreset}{...}

{title:Syntax}

{p 8 18 2}
{cmd:EY}
	Ylow Yhigh
	[{cmd:,} {it:options} {cmd: reps(#) level(#) nocc nodu testnull(M) size(#)}]

{synoptset 24 tabbed}{...}
{synopthdr}
{synoptline}

{synopt :{opt reps:}} Perform # bootstrap replications; default is reps(50). {p_end}
{synopt :{opt lev:el}} Set confidence level; default is level(.95). {p_end}
{synopt :{opt nocc:}} Suppress estimation of confidence collections based on the Hausdorff distance. {p_end}
{synopt :{opt nodu:}} Suppress estimation of confidence set based on the directed Hausdorff distance. {p_end}
{synopt :{opt test:null(M)}} Implements hypothesis tests of inclusion/equality of test set M of mean intervals with the estimated identification region 
	for the mean.  {p_end}
{synopt :{opt size:}} Perform bootstrap with sample size #; default size is the size of the original data. {p_end}

{title:Description}

{pstd}
{cmd:EY} Implements estimation and inference of the identification regions for the mean as 
described in Beresteanu and Molinari (Econometrica, 2008) using the method described on page 780.  Typing

{phang2}
{cmd:. EY} Ylow Yhigh

{pstd}
executes the estimation procedure, displaying lower and upper bounds of the estimated identification region for the mean. 
Note that the Ylow variable contains the lower bounds on the 
dependent variable and the Yhigh variable contains the upper bounds on the dependent variable.

{pstd}
This command also implements inference using nonparameteric bootstrap to obtain the following statistics:

{phang2}
(1) Critical values to use for inference regarding the identification region of the mean based 
	on the Hausdorff and directed Hausdorff distances.

{phang2}
(2) Confidence collections for the estimated identification region of the mean based on the Hausdorff distance (CC).  The confidence collection
	is the collection of all sets that cannot be rejected by the equality test.

{phang2}
(3) Confidence sets for the estimated identification region of the mean based on the directed Hausdorff distance (DU).  The confidence set, 
	the union of all sets that cannot be rejected by the inclusion test, represents the largest set that cannot be rejected by the inclusion test.

{phang2}
(4) Conclusion from hypothesis tests of the test set specified in the test option with the estimated identification region for the mean.

{pstd}
Use {help oneDproj} and/or {help CI1D} if you are interested in estimating the identification regions based on a model with covariates.

{title:Options}

{pstd}
{cmd:testnull} implements hypothesis tests for inclusion/equality of the test set, specified in matrix M, with the estimated identification region for the 
mean via the critical values based on the directed Hausdorff/Hausdorff distances.  M must be specified as a Stata matrix and must be a 1 x 2 matrix 
of the mean interval to be tested.  The first column of M must contain the lower bound of the test region for the mean, while the second column of 
matrix M must contain the upper bound of the test region for the mean.  

{title:Examples}

{pstd}Only critical values requested{p_end}
{phang2}{cmd:. EY Ylow Yhigh, nodu nocc}{p_end}

{pstd}Test of mean set requested at 90% confidence level{p_end}
{phang2}{cmd:. matrix M = [1,2]}{p_end}
{phang2}{cmd:. EY Ylow Yhigh, test(M) lev(.90)}{p_end}

{title:Saved results}

{pstd}
{cmd:EY} saves the following in {cmd:e()}:

{synoptset 25 tabbed}{...}
{p2col 5 25 29 2: Scalars}{p_end}
{synopt:{cmd:e(lb)}}Lower bound of the estimated identification region for the mean{p_end}
{synopt:{cmd:e(ub)}}Upper bound of the estimated identification region for the mean{p_end}

{synopt:{cmd:e(cr_H)}}Critical values for the mean, based on Hausdorff distance{p_end}
{synopt:{cmd:e(cr_dH)}}Critical values for the mean, based on directed Hausdorff distance{p_end}

{synopt:{cmd:e(CC_L_1)}}Lower bound of lower set of confidence collection for the mean, based on Hausdorff distance{p_end}
{synopt:{cmd:e(CC_L_2)}}Upper bound of lower set of confidence collection for the mean, based on Hausdorff distance{p_end}
{synopt:{cmd:e(CC_U_1)}}Lower bound of upper set of confidence collection for the mean, based on Hausdorff distance{p_end}
{synopt:{cmd:e(CC_U_2)}}Upper bound of upper set of confidence collection for the mean, based on Hausdorff distance{p_end}

{synopt:{cmd:e(DU_L)}}Lower bound of confidence set for the mean, based on directed Hausdorff distance{p_end}
{synopt:{cmd:e(DU_U)}}Upper bound of confidence set for the mean, based on directed Hausdorff distance{p_end}

{p2colreset}{...}


{title:Also see}

{psee}
{space 2}Help:  {help oneDproj} , {help CI1D}{break}
{p_end}
