{smcl}
{* *! version 1.0.0  3feb2010}{...}
{cmd:help ball}{right:dialog:  {dialog ball}{space 1}}
{right:also see:  {help CI2D}}
{hline}

{title:Title}

{p2colset 5 22 24 2}{...}
{p2col : ball {hline 2}} Creates a ball in R^2 to be used to create two-dimensional confidence regions in {help CI2D}{p_end}
{p2colreset}{...}


{title:Syntax}

{p 8 18 2}
{cmd:ball}
	[{cmd:,} {it:options} {cmd: radius(#) number(#)}]

{synoptset 24 tabbed}{...}
{synopthdr}
{synoptline}

{synopt :{opt rad:ius}} Create a ball in R^2 with radius #; default is radius(1). {p_end}
{synopt :{opt num:ber}} Create a ball in R^2 with # angle divisions; default is number(360). {p_end}

{title:Description}

{pstd}
{cmd:ball} creates a ball in R^2 with the radius specified in the radius option and the number of angle divisions specified in the number option.  
	The ball is assumed to be centered at the origin and the resulting coordinates are ordered with the smallest y-value first (smallest x-value
	in the case of a tie) and continues counter-clockwise. 
	
{pstd}
This command is called by {help CI2D} which implements estimation and inference of the two-dimensional identification regions of BLP coefficients 
from Beresteanu and Molinari (Econometrica, 2008).

{title:Examples}

{pstd}A ball in R^2 with radius of 2 and 60 divisions requested{p_end}
{phang2}{cmd:. ball, radius(2) number(60)}{p_end}

{title:Saved results}

{pstd}
{cmd:ball} saves the following in {cmd:r()}:

{synoptset 25 tabbed}{...}
{p2col 5 25 29 2: Matrices}{p_end}
{synopt:{cmd:r(B)}}Matrix of coordinates for ball in R^2{p_end}

{p2colreset}{...}

{title:Also see}

{psee}
{space 2}Help:  {help CI2D}{break}
{p_end}
